
const display = document.getElementById('display');
let currentInput = '';
let firstOperand = null;
let operator = null;

document.querySelectorAll('button').forEach((button) => {
    button.addEventListener('click', (e) => {
        handleButtonClick(e.target.textContent);
    });
});

function handleButtonClick(value) {
    if (value === 'C') {
        clearCalculator();
    } else if (value.match(/[0-9]/)) {
        appendDigit(value);
    } else if (value === '.' && !currentInput.includes('.')) {
        appendDecimal();
    } else if (value.match(/[\+\-\*\/]/)) {
        handleOperator(value);
    } else if (value === '=') {
        calculateResult();
    }
}

function appendDigit(digit) {
    currentInput += digit;
    updateDisplay();
}

function appendDecimal() {
    currentInput += '.';
    updateDisplay();
}

function handleOperator(op) {
    if (firstOperand === null) {
        firstOperand = parseFloat(currentInput);
        operator = op;
        currentInput = '';
    } else {
        calculateResult();
        operator = op;
    }
}

function calculateResult() {
    if (operator === null || firstOperand === null) return;
    const secondOperand = parseFloat(currentInput);
    switch (operator) {
        case '+':
            currentInput = (firstOperand + secondOperand).toString();
            break;
        case '-':
            currentInput = (firstOperand - secondOperand).toString();
            break;
        case '*':
            currentInput = (firstOperand * secondOperand).toString();
            break;
        case '/':
            currentInput = (firstOperand / secondOperand).toString();
            break;
    }
    firstOperand = null;
    operator = null;
    updateDisplay();
}

function clearCalculator() {
    currentInput = '';
    firstOperand = null;
    operator = null;
    updateDisplay();
}

function updateDisplay() {
    display.value = currentInput;
}
